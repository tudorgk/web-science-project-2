CurlMulti() -> New CurlMulti object

Creates a new :ref:`curlmultiobject` which corresponds to
a ``CURLM`` handle in libcurl.
