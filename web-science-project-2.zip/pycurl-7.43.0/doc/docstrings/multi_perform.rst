perform() -> tuple of status and the number of active Curl objects

Corresponds to `curl_multi_perform`_ in libcurl.

.. _curl_multi_perform:
    http://curl.haxx.se/libcurl/c/curl_multi_perform.html
