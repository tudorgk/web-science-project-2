errstr() -> string

Return the internal libcurl error buffer of this handle as a string.

Return value is a ``str`` instance on all Python versions.
