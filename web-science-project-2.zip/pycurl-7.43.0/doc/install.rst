.. include:: ../INSTALL.rst
