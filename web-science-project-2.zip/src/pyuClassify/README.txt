pyuClassify
============

pyuClassify_ is an Python Wrapper for accessing uClassify_ services.

``pyuClassify`` provides a API for accessing services of uclassify.com. 

.. _pyuClassify: https://github.com/psibi/pyuClassify
.. _uClassify: http://www.uclassify.com

Installation
-------------

It is very easy to install pyuClassify.

    (pip install | easy_install) uclassify

... or in the traditional way:

    git clone git://github.com/psibi/pyuClassify.git
    cd uclassify
    python setup.py install

Bug Report
-----------

Submit it here_.

.. _here: https://github.com/psibi/pyuClassify/issues

License
--------
GNU General Public License v3 (GPLv3)

